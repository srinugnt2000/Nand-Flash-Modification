#define U_BOOT_DATE "Dec 24 2013"
#define U_BOOT_TIME "14:01:44"
