
/* Automatically generated - do not edit */
#define CONFIG_BOARDDIR board/davinci/da8xxevm
#include <configs/da850evm.h>
#include <asm/config.h>
