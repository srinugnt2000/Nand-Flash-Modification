#ifndef _SPD_SDRAM_H_
#define _SPD_SDRAM_H_

long int spd_sdram(void);

#endif
